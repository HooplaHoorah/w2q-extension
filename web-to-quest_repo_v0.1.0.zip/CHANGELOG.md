## Changelog

### v0.1.0 (MVP)
- Local steps/hints/check with CSP-safe parser
- Auto-expanding Steps with Show all/Collapse
- Side panel selection handoff
- How-to box and UX polish
