# Web-to-Quest (Chrome MV3)

Turn on-page math into a guided quest: **Steps**, **Hints**, and **Answer Check** — plus an auto-expanding Steps view.

**How to use**
1. Select a math expression on any page.
2. Right-click → *Send selection → Web-to-Quest* (or paste into **Problem**).
3. Click **Generate steps** and/or **Hint me** for guidance.
4. Type your answer, then click **Check answer** (the correct result is only shown here).

## Install (Developer mode)
1. Open `chrome://extensions` and enable *Developer mode*.
2. Click **Load unpacked** and select the `/extension` folder.
3. Try it on any page.

## Tech
- Chrome **Manifest V3**, Side Panel UI.
- **CSP-safe** arithmetic engine (no `eval`), shunting-yard parser.
- Auto-expanding Steps box with *Show all / Collapse*.
- Zero data leaves device (privacy-first).

## Roadmap (v0.2.0)
- **Explain this step** (Gemini Prompt API for Extensions — on-device Nano).
- **Generate printable variants** (Writer API → PDF export).
- (Optional) **Image → equation** via multimodal Prompt API.

## Development
- Code lives under `/extension`.
- Lint & package on tag via GitHub Actions (see `.github/workflows/build.yml`).

## License
MIT © 2025 Hoopla Hoorah, LLC
