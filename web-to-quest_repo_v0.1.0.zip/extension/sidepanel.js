// --- sidepanel.js (v3.3) ---
const KEY = 'W2Q_SELECTION';
const storeSess = chrome.storage?.session;
const store = storeSess || chrome.storage.local;

function $(sel){ return document.querySelector(sel); }
const problemEl = () => $('#problem');
const answerEl  = () => $('#answer');
const stepsOut  = () => $('#outSteps');
const hintsOut  = () => $('#outHints');
const answerOut = () => $('#outAnswer');


// --- expandable helper for Steps box ---
function updateExpandable(el, toggle){
  if (!el || !toggle) return;
  // Measure content height
  const needs = el.scrollHeight > 170; // threshold a bit bigger than max-height
  toggle.hidden = !needs;
  if (!needs){ el.dataset.expanded = 'false'; el.style.maxHeight = ''; return; }
  if (el.dataset.expanded === 'true'){
    el.style.maxHeight = el.scrollHeight + 'px';
    toggle.textContent = 'Collapse';
  } else {
    el.style.maxHeight = '160px';
    toggle.textContent = 'Show all';
  }
}
function setProblem(v=''){ const el=problemEl(); if(el) el.value=v; }
function getProblem(){ return problemEl()?.value?.trim() || ''; }
function getAnswer(){  return answerEl()?.value?.trim()  || ''; }

async function prefillFromStorage(){
  try{
    const obj = await store.get(KEY);
    if (obj && obj[KEY]){
      setProblem(obj[KEY]);
      await store.remove(KEY);
    }
  }catch(e){ console.warn('[W2Q] prefill failed', e); }
}

function wire(){
  $('#btnSteps')?.addEventListener('click', ()=>{
    try { stepsOut().textContent = ((window.W2Q||globalThis).generateSteps)(getProblem()); }
    catch(e){ stepsOut().textContent = 'Error: '+ e.message; }
  });
  $('#btnHint')?.addEventListener('click', ()=>{
    try { hintsOut().textContent = ((window.W2Q||globalThis).genHint)(getProblem()); }
    catch(e){ hintsOut().textContent = 'Error: '+ e.message; }
  });
  $('#btnCheck')?.addEventListener('click', ()=>{
    try { const {verdict}=((window.W2Q||globalThis).checkAnswer)(getProblem(), getAnswer()); answerOut().textContent = verdict; }
    catch(e){ answerOut().textContent = 'Error: '+ e.message; }
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  const stepsToggle = document.querySelector('#stepsToggle');
  stepsToggle?.addEventListener('click', ()=>{
    const box=document.querySelector('#outSteps');
    if(!box) return;
    box.dataset.expanded = box.dataset.expanded === 'true' ? 'false' : 'true';
    updateExpandable(box, stepsToggle);
  });
  wire();
  await prefillFromStorage();
});

// Listen for changes in whichever storage bucket we used
(chrome.storage?.session || chrome.storage).onChanged.addListener((changes, area) => {
  if (changes[KEY]?.newValue) setProblem(changes[KEY].newValue);
});
