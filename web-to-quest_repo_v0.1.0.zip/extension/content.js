// Reserved for future: capture selection via hotkey, annotate page, etc.
