# Contributing

1. Create a feature branch from `dev`.
2. Keep changes scoped; include a short demo (gif/mp4) for UI changes.
3. Open a PR into `dev`. We squash-merge to keep history tidy.
