# Privacy

This extension evaluates math **locally** in the side panel. No data leaves your device by default.
Planned Gemini features will support an **Offline (Nano)** mode by default, with optional **Hybrid** cloud
for bulk worksheet generation. Any cloud actions will be clearly labeled.
